import logo from "../assets/Logo.svg";
import logoarrow from "../assets/logoarrow.svg";
import home from "../assets/home.png";
import welcome from "../assets/welcome.svg";
import avatar from "../assets/avatar.svg";
import notification from "../assets/notification.png";
import help from "../assets/help.png";

export { logo, welcome, notification, help, avatar, home, logoarrow };
